# myhackathon
This library was created as an example of how to publish your own python package

## building this package locally
'python setup.py sdist'

## installing this package from GitHub
'pip installing git'

## updating this package from GitHub
